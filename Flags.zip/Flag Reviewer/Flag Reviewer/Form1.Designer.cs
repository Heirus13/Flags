﻿namespace Flag_Reviewer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleCheckbox = new System.Windows.Forms.CheckBox();
            this.CountryNameCheckbox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ProgrammerCheckbox = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PhilippinesRadioButton = new System.Windows.Forms.RadioButton();
            this.ColumbiaRadioButton = new System.Windows.Forms.RadioButton();
            this.USARadioButton = new System.Windows.Forms.RadioButton();
            this.FranceRadioButton = new System.Windows.Forms.RadioButton();
            this.CountryNameLabel = new System.Windows.Forms.Label();
            this.countryPicture = new System.Windows.Forms.PictureBox();
            this.FlagViewerLabel = new System.Windows.Forms.Label();
            this.ProgrammerLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.countryPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // TitleCheckbox
            // 
            this.TitleCheckbox.AutoSize = true;
            this.TitleCheckbox.Location = new System.Drawing.Point(23, 36);
            this.TitleCheckbox.Name = "TitleCheckbox";
            this.TitleCheckbox.Size = new System.Drawing.Size(46, 17);
            this.TitleCheckbox.TabIndex = 0;
            this.TitleCheckbox.Text = "Title";
            this.TitleCheckbox.UseVisualStyleBackColor = true;
            this.TitleCheckbox.CheckedChanged += new System.EventHandler(this.TitleCheckbox_CheckedChanged);
            // 
            // CountryNameCheckbox
            // 
            this.CountryNameCheckbox.AutoSize = true;
            this.CountryNameCheckbox.Location = new System.Drawing.Point(23, 59);
            this.CountryNameCheckbox.Name = "CountryNameCheckbox";
            this.CountryNameCheckbox.Size = new System.Drawing.Size(93, 17);
            this.CountryNameCheckbox.TabIndex = 1;
            this.CountryNameCheckbox.Text = "Country Name";
            this.CountryNameCheckbox.UseVisualStyleBackColor = true;
            this.CountryNameCheckbox.CheckedChanged += new System.EventHandler(this.CountryNameCheckbox_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ProgrammerCheckbox);
            this.groupBox1.Controls.Add(this.CountryNameCheckbox);
            this.groupBox1.Controls.Add(this.TitleCheckbox);
            this.groupBox1.Location = new System.Drawing.Point(460, 136);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(152, 135);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Display";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // ProgrammerCheckbox
            // 
            this.ProgrammerCheckbox.AutoSize = true;
            this.ProgrammerCheckbox.Location = new System.Drawing.Point(23, 82);
            this.ProgrammerCheckbox.Name = "ProgrammerCheckbox";
            this.ProgrammerCheckbox.Size = new System.Drawing.Size(82, 17);
            this.ProgrammerCheckbox.TabIndex = 3;
            this.ProgrammerCheckbox.Text = "Programmer";
            this.ProgrammerCheckbox.UseVisualStyleBackColor = true;
            this.ProgrammerCheckbox.CheckedChanged += new System.EventHandler(this.ProgrammerCheckbox_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.FranceRadioButton);
            this.groupBox2.Controls.Add(this.USARadioButton);
            this.groupBox2.Controls.Add(this.ColumbiaRadioButton);
            this.groupBox2.Controls.Add(this.PhilippinesRadioButton);
            this.groupBox2.Location = new System.Drawing.Point(37, 136);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(144, 135);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Country";
            // 
            // PhilippinesRadioButton
            // 
            this.PhilippinesRadioButton.AutoSize = true;
            this.PhilippinesRadioButton.Location = new System.Drawing.Point(23, 24);
            this.PhilippinesRadioButton.Name = "PhilippinesRadioButton";
            this.PhilippinesRadioButton.Size = new System.Drawing.Size(75, 17);
            this.PhilippinesRadioButton.TabIndex = 0;
            this.PhilippinesRadioButton.TabStop = true;
            this.PhilippinesRadioButton.Text = "Philippines";
            this.PhilippinesRadioButton.UseVisualStyleBackColor = true;
            this.PhilippinesRadioButton.CheckedChanged += new System.EventHandler(this.PhilippinesRadioButton_CheckedChanged);
            // 
            // ColumbiaRadioButton
            // 
            this.ColumbiaRadioButton.AutoSize = true;
            this.ColumbiaRadioButton.Location = new System.Drawing.Point(23, 47);
            this.ColumbiaRadioButton.Name = "ColumbiaRadioButton";
            this.ColumbiaRadioButton.Size = new System.Drawing.Size(68, 17);
            this.ColumbiaRadioButton.TabIndex = 1;
            this.ColumbiaRadioButton.TabStop = true;
            this.ColumbiaRadioButton.Text = "Colombia";
            this.ColumbiaRadioButton.UseVisualStyleBackColor = true;
            this.ColumbiaRadioButton.CheckedChanged += new System.EventHandler(this.ColumbiaRadioButton_CheckedChanged);
            // 
            // USARadioButton
            // 
            this.USARadioButton.AutoSize = true;
            this.USARadioButton.Location = new System.Drawing.Point(23, 70);
            this.USARadioButton.Name = "USARadioButton";
            this.USARadioButton.Size = new System.Drawing.Size(47, 17);
            this.USARadioButton.TabIndex = 2;
            this.USARadioButton.TabStop = true;
            this.USARadioButton.Text = "USA";
            this.USARadioButton.UseVisualStyleBackColor = true;
            this.USARadioButton.CheckedChanged += new System.EventHandler(this.USARadioButton_CheckedChanged);
            // 
            // FranceRadioButton
            // 
            this.FranceRadioButton.AutoSize = true;
            this.FranceRadioButton.Location = new System.Drawing.Point(23, 93);
            this.FranceRadioButton.Name = "FranceRadioButton";
            this.FranceRadioButton.Size = new System.Drawing.Size(58, 17);
            this.FranceRadioButton.TabIndex = 3;
            this.FranceRadioButton.TabStop = true;
            this.FranceRadioButton.Text = "France";
            this.FranceRadioButton.UseVisualStyleBackColor = true;
            this.FranceRadioButton.CheckedChanged += new System.EventHandler(this.FranceRadioButton_CheckedChanged);
            // 
            // CountryNameLabel
            // 
            this.CountryNameLabel.AutoSize = true;
            this.CountryNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountryNameLabel.Location = new System.Drawing.Point(228, 289);
            this.CountryNameLabel.Name = "CountryNameLabel";
            this.CountryNameLabel.Size = new System.Drawing.Size(0, 20);
            this.CountryNameLabel.TabIndex = 5;
            this.CountryNameLabel.Visible = false;
            this.CountryNameLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // countryPicture
            // 
            this.countryPicture.Location = new System.Drawing.Point(232, 136);
            this.countryPicture.Name = "countryPicture";
            this.countryPicture.Size = new System.Drawing.Size(181, 135);
            this.countryPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.countryPicture.TabIndex = 6;
            this.countryPicture.TabStop = false;
            // 
            // FlagViewerLabel
            // 
            this.FlagViewerLabel.AutoSize = true;
            this.FlagViewerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FlagViewerLabel.Location = new System.Drawing.Point(227, 88);
            this.FlagViewerLabel.Name = "FlagViewerLabel";
            this.FlagViewerLabel.Size = new System.Drawing.Size(166, 25);
            this.FlagViewerLabel.TabIndex = 7;
            this.FlagViewerLabel.Text = "FLAG VIEWER";
            this.FlagViewerLabel.Visible = false;
            this.FlagViewerLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // ProgrammerLabel
            // 
            this.ProgrammerLabel.AutoSize = true;
            this.ProgrammerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProgrammerLabel.Location = new System.Drawing.Point(57, 388);
            this.ProgrammerLabel.Name = "ProgrammerLabel";
            this.ProgrammerLabel.Size = new System.Drawing.Size(0, 24);
            this.ProgrammerLabel.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 450);
            this.Controls.Add(this.ProgrammerLabel);
            this.Controls.Add(this.FlagViewerLabel);
            this.Controls.Add(this.countryPicture);
            this.Controls.Add(this.CountryNameLabel);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Viewer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.countryPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox TitleCheckbox;
        private System.Windows.Forms.CheckBox CountryNameCheckbox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox ProgrammerCheckbox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton FranceRadioButton;
        private System.Windows.Forms.RadioButton USARadioButton;
        private System.Windows.Forms.RadioButton ColumbiaRadioButton;
        private System.Windows.Forms.RadioButton PhilippinesRadioButton;
        private System.Windows.Forms.Label CountryNameLabel;
        private System.Windows.Forms.PictureBox countryPicture;
        private System.Windows.Forms.Label FlagViewerLabel;
        private System.Windows.Forms.Label ProgrammerLabel;
    }
}

