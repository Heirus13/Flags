﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Flag_Reviewer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ProgrammerCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (ProgrammerCheckbox.Checked)
            {
                ProgrammerLabel.Text = "Prog Rammer";
                ProgrammerLabel.Visible = true;
            }
            else
                ProgrammerLabel.Visible = false;
        }

        private void CountryNameCheckbox_CheckedChanged(object sender, EventArgs e)
        { 
            if (CountryNameCheckbox.Checked)
                CountryNameLabel.Visible = true;
            else
                CountryNameLabel.Visible = false;
        }

        private void TitleCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (TitleCheckbox.Checked)
                FlagViewerLabel.Visible = true;
            else
                FlagViewerLabel.Visible = false;
        }

        private void PhilippinesRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (PhilippinesRadioButton.Checked)
            {
                Image image = Image.FromFile(@"C:\Users\Justiniane\OneDrive\Desktop\Flag Reviewer\Flag Reviewer\Philippines.jpg");
                countryPicture.Image = image;
                CountryNameLabel.Text = "Philippines";
            }
        }

        private void ColumbiaRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (ColumbiaRadioButton.Checked)
            {
                Image image = Image.FromFile(@"C:\Users\Justiniane\OneDrive\Desktop\Flag Reviewer\Flag Reviewer\Colombia.png");
                countryPicture.Image = image;
                CountryNameLabel.Text = "Colombia";
            }

        }

        private void USARadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (USARadioButton.Checked)
            {
                Image image = Image.FromFile(@"C:\Users\Justiniane\OneDrive\Desktop\Flag Reviewer\Flag Reviewer\USA.png");
                countryPicture.Image = image;
                CountryNameLabel.Text = "USA";
            }
        }

        private void FranceRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (FranceRadioButton.Checked)
            {
                Image image = Image.FromFile(@"C:\Users\Justiniane\OneDrive\Desktop\Flag Reviewer\Flag Reviewer\France.png");
                countryPicture.Image = image;
                CountryNameLabel.Text = "France";
            }

        }
    }
    }

